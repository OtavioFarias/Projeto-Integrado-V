
module TopModule (
    input  osc_clk,
    input  reset_n,
    inout  [0:0] ddr_sdram_mem_clk,   // ddr_memory.mem_clk
    inout  [0:0] ddr_sdram_mem_clk_n, // .mem_clk_n
    output [0:0] ddr_sdram_mem_cs_n,  // .mem_cs_n
    output [0:0] ddr_sdram_mem_cke,   // .mem_cke
	 output [12:0] ddr_sdram_mem_addr, // .mem_addr
    output [1:0]  ddr_sdram_mem_ba,   // .mem_ba
    output ddr_sdram_mem_ras_n,       // .mem_ras_n
    output ddr_sdram_mem_cas_n,       // .mem_cas_n
 	 output ddr_sdram_mem_we_n, 		  // .mem_we_n
	 inout [15:0] ddr_sdram_mem_dq,    // .mem_dq
	 inout [1:0] ddr_sdram_mem_dqs,    // .mem_dqs
	 output [1:0] ddr_sdram_mem_dm,    // .mem_dm
	 output [31:0] memanswer, 
	 output reg setanswer
);


QsysModule QsysModule_inst(
		.osc_clk_clk(osc_clk),           				//      osc_clk.clk
		.reset_reset_n(reset_n),          				//        reset.reset_n
		//.soft_reset_n_reset_n(soft_reset_c),       // soft_reset_n.reset_n
		.ddr_memory_mem_clk(ddr_sdram_mem_clk),
      .ddr_memory_mem_clk_n(ddr_sdram_mem_clk_n),
      .ddr_memory_mem_cs_n(ddr_sdram_mem_cs_n),
      .ddr_memory_mem_cke(ddr_sdram_mem_cke),
      .ddr_memory_mem_addr(ddr_sdram_mem_addr),
      .ddr_memory_mem_ba(ddr_sdram_mem_ba),
      .ddr_memory_mem_ras_n(ddr_sdram_mem_ras_n),
      .ddr_memory_mem_cas_n(ddr_sdram_mem_cas_n),
      .ddr_memory_mem_we_n(ddr_sdram_mem_we_n),
      .ddr_memory_mem_dq(ddr_sdram_mem_dq),
      .ddr_memory_mem_dqs(ddr_sdram_mem_dqs),
      .ddr_memory_mem_dm(ddr_sdram_mem_dm),
		//ddr_local_refresh_ack(), 						 //          ddr.local_refresh_ack
		.ddr_local_init_done(ddr_local_init_done_c),  //             .local_init_done
	
	);

endmodule
