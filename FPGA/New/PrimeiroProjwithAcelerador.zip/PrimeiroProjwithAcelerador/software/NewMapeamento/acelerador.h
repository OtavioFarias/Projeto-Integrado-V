
#ifndef ACELERADOR_H
#define ACELERADOR_H

#define requestToHW (volatile char *) REQUESTFROMNIOS_BASE

/*
#define addressToHW (volatile int *) ADDRESSFROMNIOS_BASE

#define dataToHW (volatile int *) DATAFROMNIOS_BASE
#define dataFromMalha (volatile int *) DATAFROMMALHA_BASE

#define readMalha (volatile char *) READFROMNIOS_BASE
#define writeMalha (volatile char *) WRITEFROMNIOS_BASE

#define datareadymalha (volatile char *) DATAREADYMALHA_BASE

#define readFIFO (volatile char *) READFIFO_BASE
#define FIFOempty (volatile char *) FIFOEMPTY_BASE
#define dataFromFIFO (volatile int *) DATAFROMFIFO_BASE

#define HWready (volatile char *) READY_BASE

void writeMalha(int address, int value);
int readMalha(int address);

int readFIFO();

void requestAcelerador(int address, int value);
*/
#endif

