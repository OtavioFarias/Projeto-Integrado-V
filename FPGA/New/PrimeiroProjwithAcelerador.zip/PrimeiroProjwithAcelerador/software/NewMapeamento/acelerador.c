#include "acelerador.h"

void writeMalha(int address, int value){

	*datareadymalha = value;
	*writeMalha = 1;

	while(*HWready == 0);

	*writeMalha = 0;

}

void readMalha(int address, int value){

	*readMalha = 1;

	while(*HWready == 0);

	*readMalha = 0;

	return *dataFromMalha;

}

int readFIFO(){

	*readFIFO = 1;

	int data = *dataFromFIFO;

	*readFIFO = 0;

	return data;

}

void requestAcelerador(int address, int value){

	while(*HWready == 0);

	*requestToHW = 1;
	*addressToHW = value;
	*dataToHW = address;

	while(*HWready == 1);

	*requestToHW = 0;

}
