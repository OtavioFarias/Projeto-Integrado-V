#include "distancia.h"
#include "mapa.h"
#include "a_star.h"
#include "comunicacao.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

//#include "altera_avalon_performance_counter.h"
//#include "system.h"

int main(void)
{
    printf("=== Sistema de Mapeamento e Navega��o (NIOS II) ===\n");

    Mapa mapa;

    mapa_reset(&mapa);

    uint8_t posX = 0, posY = 0;
    uint8_t distDir = 0, distEsq = 0;
    bool direcaoHorizontal = true;

    result_t resultadoBusca;
    uint8_t caminho_saida[TAMANHO_MALHA_TOTAL];

//debug
int i = 0;

    while (1) {

        // Inicializa medi��o de performance
   //     PERF_RESET(PERFORMANCE_COUNTER_0_BASE);
    //    PERF_START_MEASURING(PERFORMANCE_COUNTER_0_BASE);

        // 1. Ler posi��o atual e sensores
        while(!sinal_mapear());
        posX = ler_pos_x();
        posY = ler_pos_y();
        distDir = ler_sensor_dir();
        distEsq = ler_sensor_esq();

        mapa_print(&mapa);

        // 2. Atualizar mapa com as novas leituras
     //   PERF_BEGIN(PERFORMANCE_COUNTER_0_BASE, 1); // Se��o 1 = mapa_atualizar
        mapa_atualizar(&mapa, posX, posY, direcaoHorizontal, distDir, distEsq);
     //   PERF_END(PERFORMANCE_COUNTER_0_BASE, 1);

        mapa_print(&mapa);

        // 3. Verifica se foi solicitado novo destino
        if (sinal_nova_rota()) {
            printf("[INFO] Solicitada nova rota. Buscando alvo...\n");

            // 3.1 Primeiro, encontra c�lula alvo mais pr�xima (via BFS)
        //    PERF_BEGIN(PERFORMANCE_COUNTER_0_BASE, 2); // Se��o 2 = bfs_raio
            resultadoBusca = bfs_raio(&mapa, posX, posY);
        //    PERF_END(PERFORMANCE_COUNTER_0_BASE, 2);

            mapa_print(&mapa);

            if (!resultadoBusca.finished) {
                printf("[AVISO] Nenhum alvo encontrado.\n");
            } else {
                printf("[INFO] Alvo encontrado em (%u, %u)\n",
                        resultadoBusca.destinoX, resultadoBusca.destinoY);

                // 3.2 Executa A* para achar menor caminho at� o alvo
           //     PERF_BEGIN(PERFORMANCE_COUNTER_0_BASE, 3); // Se��o 3 = aStar_direct
                int caminho_len = aStar_direct(&mapa,
                                               posX, posY,
                                               resultadoBusca.destinoX, resultadoBusca.destinoY,
                                               caminho_saida);
              //  PERF_END(PERFORMANCE_COUNTER_0_BASE, 3);

                if (caminho_len > 0) {
                    // 3.3 Executa a fun��o caminho
                    caminho(caminho_saida);

                    printf("[SUCESSO] Caminho calculado com %d passos.\n", caminho_len);
                } else {
                    printf("[ERRO] Falha ao calcular caminho.\n");
                }
            }
        }

        // Receber mapa atualizado via comunica��o
          receberMapa(&mapa);


       // PERF_STOP_MEASURING(PERFORMANCE_COUNTER_0_BASE);
/*
	// Imprime relat�rio de performance
        perf_print_formatted_report((void*)PERFORMANCE_COUNTER_0_BASE,
                                    ALT_CPU_FREQ, 3,
                                    "Mapa Atualizar",
                                    "BFS",
                                    "A*");
*/
        //debug
        i++;
        if(i == 10) break;

        //break; // s� para teste
    }


    return 0;
}
