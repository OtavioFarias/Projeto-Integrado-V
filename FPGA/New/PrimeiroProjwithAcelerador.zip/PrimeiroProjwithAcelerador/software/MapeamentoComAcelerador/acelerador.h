
#ifndef ACELERADOR_H
#define ACELERADOR_H

#include "system.h"

#define requestToHW (volatile char *) REQUESTFROMNIOS_BASE

#define addressToHW (volatile int *) ADDRESSFROMNIOS_BASE

#define dataToHW (volatile int *) DATAFROMNIOS_BASE
#define dataFromMalha (volatile int *) DATAFROMMALHA_BASE

#define readMalhaPointer (volatile char *) READFROMNIOS_BASE
#define writeMalhaPointer (volatile char *) WRITEFROMNIOS_BASE

#define datareadymalha (volatile char *) DATAREADYMALHA_BASE

#define readFIFOPointer (volatile char *) READFIFO_BASE
#define FIFOempty (volatile char *) FIFOEMPTY_BASE
#define dataFromFIFO (volatile int *) DATAFROMFIFO_BASE

#define HWready (volatile char *) READY_BASE


void writeMalha(int address, int value);

int readMalha(int address);

int readFIFO();

void requestAcelerador(int address, int value);

#endif

