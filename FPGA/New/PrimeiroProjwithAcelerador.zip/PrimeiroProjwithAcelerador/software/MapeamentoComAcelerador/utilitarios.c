#include "utilitarios.h"

int separarBits(int n, int inicio, int fim){

	int valor = (n >> inicio) & ((1 << (fim - inicio + 1)) - 1);
	return valor;

}

int escreverBits(int n, int inicio, int fim, int v){

	// 1. Zera a faixa de bits
	n &= ~(((1 << (fim - inicio + 1)) - 1) << inicio);

	// 2. Escreve o novo valor
	n |= (v & ((1 << (fim - inicio + 1)) - 1)) << inicio;

	return n;

}
