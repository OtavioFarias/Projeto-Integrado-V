
#include "mapa.h"

static inline int idx(int x, int y) {
    return y * TAMANHO_MALHA + x;
}

// Marca vizinhos desconhecidos como fronteira
static inline void marcar_vizinhos_fronteira(/*Mapa *m, */int x, int y) {
    static const int dx[4] = {1, -1, 0, 0};
    static const int dy[4] = {0, 0, 1, -1};

    int i;
    for (i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if ((unsigned)nx < TAMANHO_MALHA && (unsigned)ny < TAMANHO_MALHA) {
            int id = idx(nx, ny);
            /*
            if (m->malha[id] == DESCONHECIDO)
                m->malha[id] = FRONTEIRA;
			*/

            int posicaoAtual;

            if((posicaoAtual = readMalha(id)) == 0)
				escreverBits(posicaoAtual, 8, 9, 3);
				writeMalha(id, posicaoAtual);

        }
    }
}



// Atualiza o mapa conforme leitura de sensores
void mapa_atualizar(/*Mapa *m,*/
                    uint8_t posX, uint8_t posY,
                    bool direcaoHorizontal,
                    uint8_t distDir, uint8_t distEsq) {

    // Marca posiÃ§Ã£o atual como livre e ajusta fronteira
    int base = idx(posX, posY);

    //m->malha[base] = LIVRE;
    int posicaoAtual = readMalha(base);
    escreverBits(posicaoAtual, 8, 9, 1);
    writeMalha(base, posicaoAtual);

    //marcar_vizinhos_fronteira(m, posX, posY);
    marcar_vizinhos_fronteira(posX, posY);

    // Direita e esquerda (horizontal ou vertical)
    int dirX = direcaoHorizontal ? 1 : 0;
    int dirY = direcaoHorizontal ? 0 : 1;

    // Marca direÃ§Ã£o â€œdireitaâ€�
    int d;
    for (d = 1; d <= distDir; d++) {
        int x = posX + d * dirX;
        int y = posY + d * dirY;
        if ((unsigned)x >= TAMANHO_MALHA || (unsigned)y >= TAMANHO_MALHA)
            break;
        int id = idx(x, y);
       // m->malha[id] = LIVRE;

        posicaoAtual = readMalha(id);
        escreverBits(posicaoAtual, 8, 9, 1);
        writeMalha(id, posicaoAtual);

        //marcar_vizinhos_fronteira(m, x, y);
        marcar_vizinhos_fronteira(x, y);
    }

    // Marca direÃ§Ã£o â€œesquerdaâ€�
    for (d = 1; d <= distEsq; d++) {
        int x = posX - d * dirX;
        int y = posY - d * dirY;
        if ((unsigned)x >= TAMANHO_MALHA || (unsigned)y >= TAMANHO_MALHA)
            break;
        int id = idx(x, y);
        //m->malha[id] = LIVRE;

        posicaoAtual = readMalha(id);
        escreverBits(posicaoAtual, 8, 9, 1);
        writeMalha(id, posicaoAtual);

        //marcar_vizinhos_fronteira(m, x, y);
        marcar_vizinhos_fronteira(x, y);

    }

    // Marca obstÃ¡culos nas extremidades
    int xDirFim = posX + distDir * dirX + dirX;
    int yDirFim = posY + distDir * dirY + dirY;
    int xEsqFim = posX - distEsq * dirX - dirX;
    int yEsqFim = posY - distEsq * dirY - dirY;

    int id_;

    if ((unsigned)xDirFim < TAMANHO_MALHA && (unsigned)yDirFim < TAMANHO_MALHA)
        //m->malha[idx(xDirFim, yDirFim)] = OCUPADO;
    	id_ = idx(xDirFim, yDirFim);
        posicaoAtual = readMalha(id_);
        escreverBits(posicaoAtual, 8, 9, 2);
        writeMalha(id_, posicaoAtual);


    if ((unsigned)xEsqFim < TAMANHO_MALHA && (unsigned)yEsqFim < TAMANHO_MALHA)
        //m->malha[idx(xEsqFim, yEsqFim)] = OCUPADO;
    	id_ = idx(xDirFim, yDirFim);
        posicaoAtual = readMalha(id_);
        escreverBits(posicaoAtual, 8, 9, 2);
        writeMalha(id_, posicaoAtual);

}

