#ifndef UTILITARIOS_H
#define UTILITARIOS_H

//os bits s�o contados da esquerda para a direita come�ando em 0
//n�mero para transformar
int separarBits(int n, int inicio, int fim);


//retorna valor a ser guardado na malha
//n n�mero original, v = valor a ser escrito (ex.: 0b1010)
int escreverBits(int n, int inicio, int fim, int v);

#endif
