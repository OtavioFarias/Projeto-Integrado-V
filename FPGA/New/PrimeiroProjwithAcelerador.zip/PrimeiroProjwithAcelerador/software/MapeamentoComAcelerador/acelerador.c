#include "acelerador.h"

void writeMalha(int address, int value){

	*dataToHW = value;
	*writeMalhaPointer = 1;

	while(*datareadymalha == 0);

	*writeMalhaPointer = 0;

}


int readMalha(int address){

	*readMalhaPointer = 1;

	while(*datareadymalha == 0);

	*readMalhaPointer = 0;

	return *dataFromMalha;

}

int readFIFO(){

	if(*FIFOempty == 1) return -1;

	*readFIFOPointer = 1;

	int data = *dataFromFIFO;

	*readFIFOPointer = 0;

	return data;

}

void requestAcelerador(int address, int value){

	while(*HWready == 0);

	*requestToHW = 1;
	*addressToHW = value;
	*dataToHW = address;

	while(*HWready == 1);

	*requestToHW = 0;

}
